"""
Digital Payment Trends in Semi-Urban and Rural Markets
Survey analysis (n = 101, Konkan region, September 2026)

Reproduces the main statistics and charts from the field project report.

Usage (from the repository root):
    python notebooks/analysis.py
    python notebooks/analysis.py path/to/your_file.xlsx

The script reads the "Clean Data" sheet. Identifier columns (Full Name,
Shop Name) are dropped on load if present and are never used.
"""
# %% [markdown]
# # Digital Payment Trends in Semi-Urban and Rural Markets
# Survey analysis of 101 respondents, Konkan region, September 2026.

# %%
import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")  # no display needed; figures are saved to disk
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy import stats

pd.set_option("display.width", 200)
pd.set_option("display.max_columns", None)

DEFAULT_PATH = "data/Digital_Payment_Trends_Anonymised.xlsx"
FIG_DIR = Path("figures")
FIG_DIR.mkdir(exist_ok=True)

NAVY, TEAL = "#1F3A5F", "#2A9D8F"

# %% [markdown]
# ## 1. Load and prepare the data

# %%
path = sys.argv[1] if len(sys.argv) > 1 else DEFAULT_PATH
df = pd.read_excel(path, sheet_name="Clean Data")
df = df.drop(columns=["Full Name", "Shop Name"], errors="ignore")  # privacy

# Derived measure: digital-leaning = primary method is not cash alone
df["Digital Leaning"] = df["Primary Payment Method"] != "Cash"

print(f"Rows: {len(df)}, columns: {df.shape[1]}")
print(f"Digital-leaning overall: {df['Digital Leaning'].sum()} of {len(df)} "
      f"({df['Digital Leaning'].mean():.1%})")


def pct(n, d):
    return f"{n} of {d} ({n / d:.1%})"


def split_multi(series):
    """Multi-select answers are stored as semicolon-separated text."""
    return series.dropna().str.split(";").explode().str.strip()


# %% [markdown]
# ## 2. Respondent profile and digital readiness

# %%
print("\n--- Respondent profile ---")
for col in ["Location Type", "Age Group", "Gender", "Occupation", "Education"]:
    print(f"\n{col}\n{df[col].value_counts().to_string()}")

print("\n--- Digital readiness ---")
n = len(df)
print("Smartphone:", pct((df["Has Smartphone"] == "Yes").sum(), n))
print("Bank account:", pct((df["Has Bank Account"] == "Yes").sum(), n))

# %% [markdown]
# ## 3. Semi-urban vs rural: primary payment method

# %%
print("\n--- Primary payment method by location ---")
ct = pd.crosstab(df["Location Type"], df["Primary Payment Method"])
print(ct)
print((pd.crosstab(df["Location Type"], df["Primary Payment Method"],
                   normalize="index") * 100).round(1))

chi2, p, dof, _ = stats.chi2_contingency(ct)
cramers_v = np.sqrt(chi2 / (ct.values.sum() * (min(ct.shape) - 1)))
print(f"\nChi-square: chi2({dof}) = {chi2:.2f}, p = {p:.4g}, "
      f"Cramer's V = {cramers_v:.2f}")

# Daily vs not daily (2x2, continuity-corrected by default in SciPy)
daily = pd.crosstab(df["Location Type"], df["Usage Frequency"] == "Daily")
chi2_d, p_d, _, _ = stats.chi2_contingency(daily, correction=True)
print(f"Daily use by location: chi2(1) = {chi2_d:.2f}, p = {p_d:.3f}")

# Digital-leaning: Fisher's exact (robust to small expected counts)
dl = pd.crosstab(df["Location Type"],
                 df["Digital Leaning"].map({True: "Digital-leaning", False: "Cash only"}))
dl = dl.loc[["Semi-Urban", "Rural"], ["Digital-leaning", "Cash only"]]  # fixed order
print(dl)
odds, p_f = stats.fisher_exact(dl.values)
print(f"Digital-leaning by location: Fisher odds ratio = {odds:.2f}, p = {p_f:.3f}")

# Chart: primary method by location
order = ["Cash", "UPI", "Combination of cash and digital", "Mobile Wallet"]
share = (pd.crosstab(df["Location Type"], df["Primary Payment Method"],
                     normalize="index")[order] * 100)
x = np.arange(len(order))
fig, ax = plt.subplots(figsize=(8, 4.5))
ax.bar(x - 0.2, share.loc["Semi-Urban"], 0.4, label="Semi-urban", color=NAVY)
ax.bar(x + 0.2, share.loc["Rural"], 0.4, label="Rural", color=TEAL)
for xi, v in zip(x - 0.2, share.loc["Semi-Urban"]):
    ax.text(xi, v + 1, f"{v:.1f}%", ha="center", fontsize=8)
for xi, v in zip(x + 0.2, share.loc["Rural"]):
    ax.text(xi, v + 1, f"{v:.1f}%", ha="center", fontsize=8)
ax.set_xticks(x, ["Cash", "UPI", "Cash + digital", "Mobile wallet"])
ax.set_ylabel("% within group")
ax.set_title("Primary payment method by location")
ax.legend(frameon=False)
ax.spines[["top", "right"]].set_visible(False)
fig.tight_layout()
fig.savefig(FIG_DIR / "fig_primary_method_by_location.png", dpi=200)
plt.close(fig)

# %% [markdown]
# ## 4. Frequency of use and drivers of adoption

# %%
print("\n--- Frequency of use by location (%) ---")
print((pd.crosstab(df["Location Type"], df["Usage Frequency"],
                   normalize="index") * 100).round(1))

print("\n--- Digital-leaning by age group ---")
age_order = ["Below 18", "18 to 25", "26 to 35", "36 to 50", "Above 50"]
age = df.groupby("Age Group")["Digital Leaning"].agg(["sum", "count", "mean"])
age = age.loc[age_order]
print(age.assign(mean=(age["mean"] * 100).round(1)))

print("\n--- Digital-leaning by income (excludes 'Prefer not to say' and blanks) ---")
inc_order = ["Below 10,000", "10,000 to 25,000", "25,000 to 50,000", "Above 50,000"]
inc = (df[df["Income Bracket"].isin(inc_order)]
       .groupby("Income Bracket")["Digital Leaning"].agg(["sum", "count", "mean"])
       .loc[inc_order])
print(inc.assign(mean=(inc["mean"] * 100).round(1)))

print("\n--- Digital-leaning by occupation, gender, education ---")
for col in ["Occupation", "Gender", "Education"]:
    t = df.groupby(col)["Digital Leaning"].agg(["sum", "count", "mean"])
    print(f"\n{col}\n{t.assign(mean=(t['mean'] * 100).round(1)).to_string()}")

# Chart: income gradient
fig, ax = plt.subplots(figsize=(7, 4.5))
ax.bar(range(4), inc["mean"] * 100, color=TEAL)
for i, (s, c, m) in enumerate(zip(inc["sum"], inc["count"], inc["mean"])):
    ax.text(i, m * 100 + 1.5, f"{m:.1%}\n({s}/{c})", ha="center", fontsize=8)
ax.set_xticks(range(4), ["< 10k", "10k-25k", "25k-50k", "> 50k"])
ax.set_xlabel("Monthly household income (Rs.)")
ax.set_ylabel("% digital-leaning")
ax.set_ylim(0, 100)
ax.set_title("Digital-leaning respondents by income bracket")
ax.spines[["top", "right"]].set_visible(False)
fig.tight_layout()
fig.savefig(FIG_DIR / "fig_digital_leaning_by_income.png", dpi=200)
plt.close(fig)

# %% [markdown]
# ## 5. Barriers, safety and future intent

# %%
print("\n--- Barriers (multi-select; counts) ---")
barriers = split_multi(df["Barrier Reason"])
print(barriers.value_counts().to_string())

print("\n--- Barriers by location (respondents citing each) ---")
b = (df.assign(Barrier=df["Barrier Reason"].str.split(";"))
       .explode("Barrier"))
b["Barrier"] = b["Barrier"].str.strip()
b = b.dropna(subset=["Barrier"]).reset_index(drop=True)  # explode repeats the index
bt = pd.crosstab(b["Barrier"], b["Location Type"])
print(bt)

# Chart: barriers by location (excluding "not applicable")
bt_plot = bt[~bt.index.str.startswith("Not applicable")]
bt_plot = bt_plot.sort_values("Semi-Urban")
fig, ax = plt.subplots(figsize=(9, 4.5))
y = np.arange(len(bt_plot))
ax.barh(y + 0.2, bt_plot["Semi-Urban"], 0.4, label="Semi-urban", color=NAVY)
ax.barh(y - 0.2, bt_plot["Rural"], 0.4, label="Rural", color=TEAL)
ax.set_yticks(y, bt_plot.index)
ax.set_xlabel("Respondents citing the barrier (multi-select)")
ax.set_title("Barriers to digital payment use, by location")
ax.legend(frameon=False)
ax.spines[["top", "right"]].set_visible(False)
fig.tight_layout()
fig.savefig(FIG_DIR / "fig_barriers_by_location.png", dpi=200)
plt.close(fig)

print("\n--- Perceived safety ---")
print(df["Perceived Safety"].value_counts().to_string())
print((pd.crosstab(df["Location Type"], df["Perceived Safety"],
                   normalize="index") * 100).round(1))
print((pd.crosstab(df["Education"], df["Perceived Safety"],
                   normalize="index") * 100).round(1))

print("\n--- Future intent ---")
print(df["Future Intent"].value_counts().to_string())
cash_first = df[df["Primary Payment Method"] == "Cash"]
print("Cash-first respondents wanting more:",
      pct((cash_first["Future Intent"] == "Yes").sum(), len(cash_first)))

# %% [markdown]
# ## 6. Merchant acceptance
# Note: the denominator is the 77 respondents who answered the merchant
# question, not the 35 shopkeepers by occupation (see Appendix B of the report).

# %%
merchant = df["Shop Accepts Digital"].dropna()
print("\n--- Merchant acceptance ---")
print("Shops accepting digital payments:",
      pct((merchant == "Yes").sum(), len(merchant)))
print((pd.crosstab(df["Location Type"], df["Shop Accepts Digital"]))
      .to_string())
